#!/usr/bin/expect -f
spawn ssh ubuntu@192.168.254.16
expect "password: "
send "%ubuntu\r"
expect "$ "
interact
